<?php
include("../config/koneksi.php");
$ID_Pelanggan = $_POST['id_pelanggan'];
$Nama_Pelanggan = $_POST['nama'];
$Alamat = $_POST['alamat'];
$Nomor_Telepon = $_POST['nomor_hp'];

$cek = mysqli_query($config, "SELECT * FROM pelanggan WHERE id_pelanggan = '$id_pelanggan'");
if (mysqli_num_rows($cek) > 0) {
    echo "<script>alert('ID barang sudah ada!'); window.history.back();</script>";
    exit(); // Hentikan script
}
$query = mysqli_query($config, "insert into pelanggan (id_pelanggan, nama, alamat, nomor_hp) values ('$ID_Pelanggan','$Nama_Pelanggan','$Alamat','$Nomor_Telepon')");
if ($query) {
	echo "<script>alert('Data Pelanggan Tersimpan !!!');location.href=('tampil_pelanggan.php');</script>";
} else {
	echo "<script type='text/javascript'>alert('Data Pelanggan Gagal Tersimpan !!!'); history.back(self);</script'";
}
?>