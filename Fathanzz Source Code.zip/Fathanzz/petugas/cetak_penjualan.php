<!doctype html>
<html lang="en">
  <head>
    <title>Aplikasi Kasir</title>
    <script language="javascript1.2">
      function printpage(){
        window.print();
      }
      </script>
  </head>
  <body onload="printpage()">
    <h2>
      <center>Data Penjualan</center>
    </h2>
    <table border="1" align="center">
      <tr>
        <th>NO</th>
        <th>ID Penjualan</th>
        <th>ID Pelanggan</th>
        <th>Tanggal Penjualan</th>
        <th>Total</th>
      </tr>
      <?php
      include("../config/koneksi.php");
      $i = 1;
      $query = mysqli_query($config, "select * from penjualan");
      while ($data = mysqli_fetch_array($query)){
        echo "<tr>
        <td>$1</td>
        <td>$data[id_penjualan]</td>
        <td>$data[id_pelanggan]</td>
        <td>$data[tgl_penjualan]</td>
        <td>Rp.$data[total]</td>
        </tr>";
        $i = $i + 1;
      }
      ?>

    </table>
    </body>
