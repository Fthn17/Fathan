<?php
include("../config/koneksi.php");
$id_barang = $_POST['id_barang'];
$nama_barang = $_POST['nama_barang'];
$harga = $_POST['harga'];
$stok = $_POST['stok'];

$cek = mysqli_query($config, "SELECT * FROM barang WHERE id_barang = '$id_barang'");
if (mysqli_num_rows($cek) > 0) {
    echo "<script>alert('ID barang sudah ada!'); window.history.back();</script>";
    exit(); // Hentikan script
}
$query = mysqli_query($config, "insert into barang (id_barang, nama_barang, harga, stok)
 values ('$id_barang','$nama_barang','$harga','$stok')");
if ($query) {
	echo "<script>alert('Data Barang Tersimpan !!!');location.href=('Tampil-Barang.php');</script>";
} else {
	echo "<script type='text/javascript'>alert('Data Produk Gagal Tersimpan !!!'); history.back(self);</script'";
}
?>