<?php
include("../config/koneksi.php");
$id_user = $_POST['id_user'];
$nama = $_POST['nama'];
$username = $_POST['username'];
$password = $_POST['password'];
$role = $_POST['role'];

$cek = mysqli_query($config, "SELECT * FROM user WHERE id_user = '$id_user'");
if (mysqli_num_rows($cek) > 0) {
    echo "<script>alert('ID pelanggan sudah ada!'); window.history.back();</script>";
    exit(); // Hentikan script
}
$query = mysqli_query($config, "insert into user (id_user, nama, username, password, role)
 values ('$id_user','$nama','$username','$password','$role')");
if ($query) {
	echo "<script>alert('Data User Tersimpan !!!');location.href=('tampil-user.php');</script>";
} else {
	echo "<script type='text/javascript'>alert('Data User Gagal Tersimpan !!!'); history.back(self);</script'";

}
?>