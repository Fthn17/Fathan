<?php
include("../config/koneksi.php");
$id_user = $_POST['id_user'];
$nama = $_POST['nama'];
$username = $_POST['username'];
$password= $_POST['password'];
$role= $_POST['role'];


$query = mysqli_query($config, "update user set id_user='$id_user', nama ='$nama', username ='$username', password='$password', role ='$role' where id_user='$id_user'");

if ($query) {
	echo "<script>alert('Data User Di Update !!!');location.href=('tampil-user.php');</script>";
} else {
	echo "<script type='text/javascript'>alert('Data User Gagal Di Update !!!'); history.back(self);</script>'";
}
?>