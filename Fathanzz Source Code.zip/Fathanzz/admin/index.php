<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] != "Admin") {
    header("Location: ../index.php");
    exit();
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" >

    <title>App Kasir | Home Admin</title>
  </head>
    <style>
        body {
            background: linear-gradient(135deg, #E3F2FD  );
          
            min-height: 100vh;
        }
        .card {
            transition: transform 0.2s ease-in-out;
            border: none;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .card:active {
            transform: scale(1.05) rotate(2deg);
        }
        .container-fluid h3, h4 {
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-info">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">App Kasir</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active text-black" aria-current="page" href="index.php">Home</a>
        </li>
           <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Barang
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="tambah-barang.php">Tambah Barang</a></li>
            <li><a class="dropdown-item" href="tampil-barang.php">Tampil Barang</a></li>
            <li><a class="dropdown-item" href="Cetak_barang.php">Cetak Barang</a></li>
          </ul>
        </li>
         <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Pelanggan
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="tambah-pelanggan.php">Tambah Pelanggan</a></li>
            <li><a class="dropdown-item" href="tampil_pelanggan.php">Tampil Pelanggan</a></li>
            <li><a class="dropdown-item" href="cetak_pelanggan.php">Cetak Pelanggan</a></li>
          </ul>
        </li>
         <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            User
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="tambah-user.php">Tambah User</a></li>
            <li><a class="dropdown-item" href="tampil-user.php">Tampil User</a></li>
            <li><a class="dropdown-item" href="cetak_user.php">Cetak User</a></li>
          </ul>
        </li>
         <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="../config/logout.php" onclick="return confirm('Apakah Anda Yakin Ingin Logout ???')">Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

    <div class="container-fluid">
  
        <h3>Home</h3>
        <h4>Selamat Datang Administrator</h4>
      >
    </div>
    <div class="row justify-content-center mt-4">
        <div class="col-md-3">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <h5 class="card-title">JUMLAH BARANG</h5>
                    <div class="display-4">
                        <?php
                        include("../config/koneksi.php");
                        $sql = mysqli_query($config, "SELECT * FROM barang");
                        echo "<b>" . mysqli_num_rows($sql) . "</b>";
                        ?>
                    </div>
                    <a href="Tampil-Barang.php" class="text-white">Lihat Detail</a>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <h5 class="card-title">JUMLAH PELANGGAN</h5>
                    <div class="display-4">
                        <?php
                        $sql = mysqli_query($config, "SELECT * FROM pelanggan");
                        echo "<b>" . mysqli_num_rows($sql) . "</b>";
                        ?>
                    </div>
                    <a href="tampil_pelanggan.php" class="text-white">Lihat Detail</a>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <h5 class="card-title">JUMLAH USER</h5>
                    <div class="display-4">
                        <?php
                        $sql = mysqli_query($config, "SELECT * FROM user");
                        echo "<b>" . mysqli_num_rows($sql) . "</b>";
                        ?>
                    </div>
                    <a href="tampil-user.php" class="text-white">Lihat Detail</a>
                </div>
            </div>
        </div>
    </div>
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>
