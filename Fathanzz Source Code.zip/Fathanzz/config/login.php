<?php
session_start();
include("koneksi.php");

// Tangkap input dan cegah SQL Injection
$username = mysqli_real_escape_string($config, $_POST['username']);
$password = md5($_POST['password']); // Gunakan password_hash di sistem yang lebih aman

// Query untuk mencari user
$login = mysqli_query($config, "SELECT * FROM user WHERE username='$username' AND password='$password'")
         or die("Query Error: " . mysqli_error($config));

$cek = mysqli_num_rows($login);

if ($cek > 0) {
    $data = mysqli_fetch_assoc($login);

    // Simpan data session
    $_SESSION['username'] = $username;
    $_SESSION['role'] = $data['role'];

    // Redirect sesuai role
    if ($data['role'] == "Admin") {
        header('location:../admin/index.php');
        exit();
    } else if ($data['role'] == "Petugas") {
        header('location:../petugas/index.php');
        exit();
    }

} else {
    // Jika login gagal, tampilkan pesan error dengan alert dan kembali ke halaman login
    echo "<script>alert('Username atau Password salah! Silakan coba lagi.'); window.history.back();</script>";
    exit();
}
?>
