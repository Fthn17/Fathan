<?php
$server = "localhost";
$user = "root";
$pass = "";
$database = "aplikasi-kasir-fathan";

$config = mysqli_connect($server,$user, $pass, $database) or die("gagal koneksi ke database");
?>